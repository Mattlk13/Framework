// Package swarmkit implements a framework for task orchestration.
package swarmkit
