### Notice

Do not change .pb.go files directly. You need to change the corresponding .proto files and run the following command to regenerate the .pb.go files.
```
$ make generate
```

Click [here](https://github.com/google/protobuf) for more information about protobuf.
