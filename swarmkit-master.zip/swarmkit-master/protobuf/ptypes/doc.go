// Package ptypes provides utility functions for use with
// gogo/protobuf/ptypes.
package ptypes
