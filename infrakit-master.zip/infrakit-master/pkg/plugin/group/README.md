Scaler controller (container).
