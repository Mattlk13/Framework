# Store API

* This API is still evolving. Provided implementations may change. *

The current iteration of the Store API does not define a plugin interface.  When the
plugin interface is finalized, we expect implementations using different backends
to reside in their own git repos.
